import React, { Component, Fragment } from 'react';
import Cart from './Cart';

class ProductList extends Component {
    constructor(props) {
        super(props);
        console.log(props.productsArray);
        this.state = {
            productsArray: props.productsArray,
            cartData: [],
            showCart: false,
            totalBill: 0,
            totalQuantity: 0
        }
    }

    addToCart = (product) => {
        let totalBill = 0;
        let totalQuantity = 0;
        const { cartData } = this.state;
        let availableArray = cartData.filter(cartItem => cartItem.pName === product.pName)
        if (availableArray.length) {
            cartData.forEach(cartItem => {
                if (cartItem.pName === product.pName) cartItem.quantity += 1
            })
        } else {
            product.quantity = 1
            cartData.push(product);
        }
        cartData.map(cartItem => {
            totalBill += cartItem.quantity * cartItem.pPrice;
            totalQuantity += cartItem.quantity
        })
        this.setState({ cartData: cartData, totalBill: totalBill, totalQuantity: totalQuantity }, () => {
            console.log(cartData);
        })
    }

    render() {
        let { showCart, cartData } = this.state;
        return (<Fragment>
            <div className="container-fluid">
                {
                    !showCart ? (
                        <Fragment>
                            <div className="row mt-5">
                                <Fragment>
                                    {
                                        this.state.productsArray.length > 0 ?
                                            // <Fragment>
                                            this.state.productsArray.map((product, index) => {
                                                return (
                                                    <div className="col-md-3 text-center" key={index}>
                                                        <div className="card shadow">
                                                            <img className="card-img-top mt-2" src={product.pImgUrl} style={{ height: "300px" }} alt={product.pName} />
                                                            <div className="card-body">
                                                                <h3 style={{ fontFamily: 'cursive' }}>{product.pName}</h3>
                                                                <h4 className="text text-success">₹ {product.pPrice}</h4>
                                                                <button className="btn btn-dark" onClick={() => this.addToCart(product)}>
                                                                    Add to <i class="fa fa-lg fa-shopping-cart" aria-hidden="true"></i>
                                                                    </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                )

                                            }
                                            ) : <h1>No Products Available!!</h1>
                                    }
                                </Fragment>
                            </div>
                            <div className="row mt-5">
                                <div className="col-md-4 offset-md-4">
                                    <button className="btn btn-outline-dark btn-lg btn-block" onClick={() => this.setState({ showCart: true })}>
                                        Go to <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                    </button>
                                </div>
                            </div>
                        </Fragment>) :
                        <div className="row col-md-6 offset-md-3 card shadow mt-5">
                            <Cart cartArray={cartData} totalBill={this.state.totalBill} totalQuantity={this.state.totalQuantity} />
                            <button className="col-md-6 offset-md-3 mb-3 btn btn-outline-dark btn-lg" onClick={() => this.setState({ showCart: false })}>Continue Shopping</button>
                        </div>
                }
            </div>
        </Fragment>)
    }

}

export default ProductList;

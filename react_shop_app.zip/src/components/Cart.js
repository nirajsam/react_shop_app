import React, { Fragment } from 'react';

let Cart = (props) => {
    const { cartArray } = props;

    return (
        <Fragment>

            {
                cartArray.length ?
                    <Fragment>
                        <h1 style={{ fontFamily: "cursive" }} className="text text-success">Your Cart has {cartArray.length} Product(s)</h1>
                        <table className="table table-bordered table-striped">
                            <thead className="thead-dark">
                                <tr>
                                    <th>Product Name</th>
                                    <th>Product Quantity</th>
                                    <th>Total Price</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    cartArray.map((cartItem, index) => {
                                        return (
                                            <tr>
                                                <td>{cartItem.pName}</td>
                                                <td>{cartItem.quantity}</td>
                                                <td>₹ {cartItem.pPrice * cartItem.quantity}</td>
                                            </tr>
                                        )
                                    })
                                }
                                <tr className="font-weight-bold">
                                    <td colSpan={2} className="text text-right">Total Quantity: {props.totalQuantity}</td>
                                    <td colSpan={2}>Total Bill: ₹ {props.totalBill}</td>

                                </tr>
                            </tbody>
                        </table>
                    </Fragment>
                    :
                    <h1 style={{ fontFamily: "cursive" }}>No Product Available in Cart</h1>
            }
        </Fragment>
    )
}

export default Cart;
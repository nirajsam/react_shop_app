import React from 'react';
// import logo from './logo.svg';
import './App.css';
// import Employee from './components/Employee';
// import Employee from './components/EmployeeClass';
// import ChildComponent1 from './components/ChildComponent1';
import ProductList from './components/ProductList';

let productsArray = [
  { pImgUrl: "/assets/iphone.jpg", pName: 'Iphone 7s', pPrice: 40000 },
  { pImgUrl: "/assets/nokiasmartphone.png", pName: 'Nokia 8', pPrice: 24000 },
  { pImgUrl: "/assets/redminote8.png", pName: 'Redmi Note 8', pPrice: 17000 },
  { pImgUrl: "/assets/samsunggalaxy.jpg", pName: 'Samsung Galaxy', pPrice: 30000 }
]

function App() {
  return (

    <div className="App">
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">Cart App</a>
      </nav>
      <ProductList productsArray={productsArray} />
    </div>
  )
}



// function App() {
//   return (
//     <div className="App">
//       <ChildComponent1 />
//     </div>
//   )
// }


// function App() {
//   // let employeesArray = ['John', 'Jack', 'Peter']
//   return (
//     <div className="App">
//       {/* <Employee /> */}
//       {/* 1. in react every tag must have a closing tag */}
//       {/* <br> ==> <br></br> ==> > <br /> */}
//       {/* {employeesArray.map((emp, index) => {
//         return <Employee key={index}>{emp}</Employee>
//       })} */}
//       {/* <Employee>Chandan - 16</Employee>
//       <Employee>Chandan - 20</Employee>
//       <Employee>Chandan - 24</Employee> */}
//       {/* <img src="" alt="" /> */}
//       <Employee name="John" age="20" />
//       <Employee name="Jack" age="22" />
//       <Employee name="Peter" age="24" />
//     </div>
//   );
// }

export default App;
